# Llm call

Make LLM calls from Python using the OpenAI SDK and the Responses API. Use when generating text, summarizing content, answering questions, extracting structured data, or adding AI-powered features to Python applications.

## Triggers

This skill is activated by the following keywords:

- `llm`
- `llm call`
- `llm application`
- `llm app`
- `openai`
- `openai api`
- `responses api`
- `model call`
- `ai generation`
- `text generation`
- `system prompt`
- `structured output`

## Details

# LLM Call Skill

This skill provides guidance for making LLM calls from Python using the OpenAI SDK.

## Capabilities

- Make LLM calls using the OpenAI Python SDK
- Write clear system prompts for task-specific behavior
- Pass both system instructions and user input to the model
- Generate plain-text responses
- Generate structured JSON output with a schema
- Reuse a simple helper class for LLM interactions
- Read configuration from environment variables
- Add basic error handling for production usage
- Mock LLM calls in tests instead of making real API requests

## Environment Variables

This skill assumes the following environment variables are already set:

```bash
export LLM_API_KEY="your_api_key_here"
export LLM_MODEL_NAME="some-model-name"
export LLM_BASE_URL="https://openrouter.ai/api/v1"
````

This skill also assumes that the `openai` Python package is already installed.

## When to Use a System Prompt

Write a system prompt when the application needs the model to follow a consistent role, style, rule set, or output format.

Use a system prompt for cases like:

* chatbots
* summarization
* extraction
* classification
* code generation
* domain-specific assistants
* formatting constraints
* safety or style rules

Keep the system prompt focused on behavior and output requirements. Put the actual task or user request in the user message.

## Plain Text Example

Use this pattern for a normal LLM call with a system prompt:

```python
import os
from openai import OpenAI

client = OpenAI(
    api_key=os.environ["LLM_API_KEY"],
    base_url=os.environ["LLM_BASE_URL"],
)

system_prompt = """
You are a helpful technical assistant.
Answer clearly and accurately.
Keep responses concise unless the user asks for more detail.
""".strip()

user_query = "Explain transformers in simple terms."

response = client.responses.create(
    model=os.environ["LLM_MODEL_NAME"],
    input=[
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": user_query},
    ],
)

print(response.output_text)
```

## Reusable Helper

Create a helper class for repeated text-generation usage:

```python
import os
from openai import OpenAI


class LLMClient:
    def __init__(self) -> None:
        self.client = OpenAI(
            api_key=os.environ["LLM_API_KEY"],
            base_url=os.environ["LLM_BASE_URL"],
        )
        self.model = os.environ["LLM_MODEL_NAME"]

    def generate_text(self, system_prompt: str, user_query: str) -> str:
        response = self.client.responses.create(
            model=self.model,
            input=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_query},
            ],
        )
        return response.output_text
```

Example usage:

```python
llm = LLMClient()

system_prompt = """
You are a helpful AI assistant for explaining machine learning concepts.
Use simple language and short examples.
""".strip()

text = llm.generate_text(
    system_prompt=system_prompt,
    user_query="Explain transformers in simple terms."
)
print(text)
```

## Structured Output with JSON Schema

Use structured output when the response will be parsed by code.

```python
import os
from openai import OpenAI

client = OpenAI(
    api_key=os.environ["LLM_API_KEY"],
    base_url=os.environ["LLM_BASE_URL"],
)

response = client.responses.create(
    model=os.environ["LLM_MODEL_NAME"],
    input=[
        {
            "role": "system",
            "content": "Extract structured information from the user input.",
        },
        {
            "role": "user",
            "content": "Alice and Bob are going to a science fair on Friday.",
        },
    ],
    text={
        "format": {
            "type": "json_schema",
            "name": "event_info",
            "strict": True,
            "schema": {
                "type": "object",
                "properties": {
                    "title": {"type": "string"},
                    "date": {"type": "string"},
                    "participants": {
                        "type": "array",
                        "items": {"type": "string"},
                    },
                },
                "required": ["title", "date", "participants"],
                "additionalProperties": False,
            },
        }
    },
)

print(response.output_text)
```

## Structured Output with Pydantic

Use this when the application already uses Python types and wants parsed output directly:

```python
import os
from pydantic import BaseModel
from openai import OpenAI


class EventInfo(BaseModel):
    title: str
    date: str
    participants: list[str]


client = OpenAI(
    api_key=os.environ["LLM_API_KEY"],
    base_url=os.environ["LLM_BASE_URL"],
)

response = client.responses.parse(
    model=os.environ["LLM_MODEL_NAME"],
    input=[
        {
            "role": "system",
            "content": "Extract structured information from the user input.",
        },
        {
            "role": "user",
            "content": "Alice and Bob are going to a science fair on Friday.",
        },
    ],
    text_format=EventInfo,
)

result = response.output_parsed
print(result.title)
print(result.date)
print(result.participants)
```

## Production-Oriented Example

Add basic error handling for safer usage in applications:

```python
import logging
import os
from openai import OpenAI

logger = logging.getLogger(__name__)


class LLMCallError(RuntimeError):
    pass


class LLMClient:
    def __init__(self) -> None:
        self.client = OpenAI(
            api_key=os.environ["LLM_API_KEY"],
            base_url=os.environ["LLM_BASE_URL"],
        )
        self.model = os.environ["LLM_MODEL_NAME"]

    def generate_text(self, system_prompt: str, user_query: str) -> str:
        try:
            response = self.client.responses.create(
                model=self.model,
                input=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_query},
                ],
            )
            return response.output_text
        except Exception as exc:
            logger.exception("LLM call failed")
            raise LLMCallError("OpenAI response generation failed") from exc
```

## Testing with Mocks

Mock the SDK boundary in tests instead of calling the real API:

```python
from unittest.mock import MagicMock

from myapp.llm_client import LLMClient


def test_generate_text() -> None:
    llm = LLMClient()
    llm.client = MagicMock()

    fake_response = MagicMock()
    fake_response.output_text = "hello world"
    llm.client.responses.create.return_value = fake_response

    result = llm.generate_text(
        system_prompt="You are a helpful assistant.",
        user_query="Say hello",
    )

    assert result == "hello world"
```

## Best Practices

* Never hardcode API keys
* Always read the API key from `LLM_API_KEY`
* Always read the model name from `LLM_MODEL_NAME`
* Always read the base URL from `LLM_BASE_URL`
* Use a system prompt when consistent behavior or formatting is required
* Put instructions in the system prompt and task data in the user message
* Prefer structured outputs when the response will be parsed by code
* Keep schemas explicit and disallow unexpected fields when needed
* Add error handling for production code
* Mock API calls in unit tests

````