---
name: llm-call
description: Make LLM calls from Python using the OpenAI SDK and the Responses API. Use when generating text, summarizing content, answering questions, extracting structured data, or adding AI-powered features to Python applications.
triggers:
- llm
- ai
- openai
- genai
- openai api
- responses api
- model call
- ai generation
- text generation
- system prompt
- structured output
---


# LLM Call Skill

Use this skill when implementing or updating Python code that calls an LLM.

## Rules

- Assume the `openai` package is already installed
- Read the API key from `LLM_API_KEY`
- Read the model name from `LLM_MODEL_NAME`
- Read the base URL from `LLM_BASE_URL`
- Use the Responses API
- Use a system prompt when the model must follow a consistent role, style, or format
- Put instructions in the system prompt and the actual task in the user message
- Prefer structured outputs when the response will be parsed by code
- Add basic error handling for production code
- Mock SDK calls in tests instead of making real API requests

## Environment Variables

```bash
export LLM_API_KEY="your_api_key_here"
export LLM_MODEL_NAME="some-model-name"
export LLM_BASE_URL="https://openrouter.ai/api/v1"
````

## Plain Text Example

```python
import os
from openai import OpenAI

client = OpenAI(
    api_key=os.environ["LLM_API_KEY"],
    base_url=os.environ["LLM_BASE_URL"],
)

system_prompt = """
You are a helpful technical assistant.
Answer clearly and accurately.
Keep responses concise unless the user asks for more detail.
""".strip()

user_query = "Explain transformers in simple terms."

response = client.responses.create(
    model=os.environ["LLM_MODEL_NAME"],
    input=[
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": user_query},
    ],
)

print(response.output_text)
```

## Reusable Helper

```python
import os
from openai import OpenAI


class LLMClient:
    def __init__(self) -> None:
        self.client = OpenAI(
            api_key=os.environ["LLM_API_KEY"],
            base_url=os.environ["LLM_BASE_URL"],
        )
        self.model = os.environ["LLM_MODEL_NAME"]

    def generate_text(self, system_prompt: str, user_query: str) -> str:
        response = self.client.responses.create(
            model=self.model,
            input=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_query},
            ],
        )
        return response.output_text
```

## Structured Output with Pydantic

```python
import os
from pydantic import BaseModel
from openai import OpenAI


class EventInfo(BaseModel):
    title: str
    date: str
    participants: list[str]


client = OpenAI(
    api_key=os.environ["LLM_API_KEY"],
    base_url=os.environ["LLM_BASE_URL"],
)

response = client.responses.parse(
    model=os.environ["LLM_MODEL_NAME"],
    input=[
        {
            "role": "system",
            "content": "Extract structured information from the user input.",
        },
        {
            "role": "user",
            "content": "Alice and Bob are going to a science fair on Friday.",
        },
    ],
    text_format=EventInfo,
)

result = response.output_parsed
print(result.title)
print(result.date)
print(result.participants)
```

## Production Pattern

```python
import logging
import os
from openai import OpenAI

logger = logging.getLogger(__name__)


class LLMCallError(RuntimeError):
    pass


class LLMClient:
    def __init__(self) -> None:
        self.client = OpenAI(
            api_key=os.environ["LLM_API_KEY"],
            base_url=os.environ["LLM_BASE_URL"],
        )
        self.model = os.environ["LLM_MODEL_NAME"]

    def generate_text(self, system_prompt: str, user_query: str) -> str:
        try:
            response = self.client.responses.create(
                model=self.model,
                input=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_query},
                ],
            )
            return response.output_text
        except Exception as exc:
            logger.exception("LLM call failed")
            raise LLMCallError("OpenAI response generation failed") from exc
```

## Testing Pattern

```python
from unittest.mock import MagicMock

from myapp.llm_client import LLMClient


def test_generate_text() -> None:
    llm = LLMClient()
    llm.client = MagicMock()

    fake_response = MagicMock()
    fake_response.output_text = "hello world"
    llm.client.responses.create.return_value = fake_response

    result = llm.generate_text(
        system_prompt="You are a helpful assistant.",
        user_query="Say hello",
    )

    assert result == "hello world"

```
```