---
name: deploy-application
description: Run the app on a secure dynamic localhost port, register it with the reverse proxy, and return the clickable application link.
triggers:
- deploy
- deploy application
- register app
- reverse proxy
- app link
- clickable link
---

# Deploy Application Skill

Use this skill when the application is ready to run and must be exposed through the shared reverse proxy.

## Rules

- Deploy means:
  1. choose a free localhost port
  2. run the app on `127.0.0.1:<port>`
  3. register the app with the reverse proxy using register curl
  4. get the json and 
  4. return the clickable application link
- Do not expose a new external port
- Keep the app bound to `127.0.0.1`
- The application slug should be created from the user’s app request, or based on what are you developing
- Return the final user-facing link as markdown:
  `[Open application](<full-url>)`

## Free Port Example

```bash
python - <<'PY'
import socket
s = socket.socket()
s.bind(("127.0.0.1", 0))
print(s.getsockname()[1])
s.close()
PY
```

## Reverse Proxy Calls for registering the application and provviding user a link to access the application

### Examples:
Register:

```bash
curl -X POST http://127.0.0.1:3000/__register \
  -H "Content-Type: application/json" \
  -d '{"slug":"todo-app","target":"http://127.0.0.1:<hosted-port>","health":"/"}'


returns: {"ok":true,"slug":"todo-app","target":"http://127.0.0.1:9123","path":"/apps/todo-app/","url":"http://127.0.0.1:3000/apps/todo-app/"}
```

List routes:

```bash
curl -H "X-Proxy-Api-Key: <key-if-configured>" http://127.0.0.1:3000/__routes


return: {"ok":true,"routes":[{"slug":"todo-app","target":"http://127.0.0.1:9123","path":"/apps/todo-app/","url":"http://127.0.0.1:3000/apps/todo-app/"}]}
```

Unregister:

```bash
curl -X DELETE  \
  http://127.0.0.1:3000/__register/todo-app

return: {"ok":true,"slug":"todo-app","removed":true}
```

## Output Rule

Always return clickable link like below:

[Open application](http://127.0.0.1:3000/apps/todo-app/)

